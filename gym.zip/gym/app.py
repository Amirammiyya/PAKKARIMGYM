from flask import Flask, render_template, request, redirect, url_for, session, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import re

app = Flask(__name__)
app.secret_key = "supersecretkey"
DATABASE = 'members.db'

# Helper function to connect to the SQLite database
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row  # Ensures that results are returned as dictionaries
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

# Input validation function (modified to allow spaces for names)
def is_valid_input(input_string):
    # Allow only alphanumeric characters and spaces, length between 3 and 20
    return re.match(r'^[a-zA-Z0-9\s]{3,20}$', input_string) is not None

@app.before_request
def create_tables():
    db = get_db()
    # Create tables if they don't exist
    db.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role TEXT NOT NULL
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        membership_status TEXT NOT NULL
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS classes (
        id INTEGER PRIMARY KEY,
        class_name TEXT NOT NULL,
        class_time TEXT NOT NULL
    )''')
    db.commit()

    # Insert default users with hashed passwords if not already present
    existing_users = query_db("SELECT COUNT(*) FROM users", one=True)
    if existing_users[0] == 0:
        db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                   ("staff", generate_password_hash("staffpass"), "staff"))
        db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                   ("member", generate_password_hash("memberpass"), "member"))
        db.commit()

# Home Route (Login)
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Validate username input
        if not is_valid_input(username):
            return "Invalid input! Username must be alphanumeric and between 3-20 characters long."

        # Fetch user from the database
        user = query_db("SELECT * FROM users WHERE username = ?", [username], one=True)
        if user and check_password_hash(user['password'], password):
            session['user'] = username
            session['role'] = user['role']
            return redirect(url_for('dashboard'))
        else:
            return "Login Failed! Invalid username or password."

    return render_template('login.html')

# Dashboard Route
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    # Get the role of the logged-in user
    role = session.get('role')
    
    # Pass role to the template to conditionally render the options
    return render_template('dashboard.html', role=role)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        # Validate username and role
        if not is_valid_input(username) or not is_valid_input(role):
            return "Invalid input! Username and role must be alphanumeric and 3-20 characters long."

        # Add password complexity validation (optional but recommended)
        if len(password) < 8 or not any(char.isdigit() for char in password) or not any(char.isalpha() for char in password):
            return "Invalid input! Password must be at least 8 characters long, containing both letters and numbers."

        # Hash the password before storing
        hashed_password = generate_password_hash(password)
        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                       (username, hashed_password, role))
            db.commit()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            return "Registration failed! Username already exists."
    return render_template('register.html')


# Register Member
@app.route('/register_member', methods=['GET', 'POST'])
def register_member():
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))  # Redirect to login if not staff
    
    if request.method == 'POST':
        name = request.form['name']
        status = request.form['status']  # 'active' or 'inactive'
        
        # Validate member name and status
        if not is_valid_input(name):  # Validate name input
            return "Invalid name! Only alphanumeric characters are allowed."
        if status not in ['active', 'inactive']:  # Validate status
            return "Invalid status! Must be 'active' or 'inactive'."

        db = get_db()
        try:
            db.execute("INSERT INTO members (name, membership_status) VALUES (?, ?)", (name, status))
            db.commit()
            return redirect(url_for('view_members'))  # Redirect to view members after registration
        except sqlite3.IntegrityError:
            return "Error: Unable to register the member."
    
    return render_template('register_member.html')  # Render the registration form


# Add Class
@app.route('/add_class', methods=['GET', 'POST'])
def add_class():
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))

    if request.method == 'POST':
        class_name = request.form['class_name']
        class_time = request.form['class_time']

        # Validate class name and class time
        if not is_valid_input(class_name) or not is_valid_input(class_time):
            return "Invalid input! Class name and class time must be alphanumeric and between 3-20 characters long."

        # Add the new class to the database
        try:
            db = get_db()
            db.execute("INSERT INTO classes (class_name, class_time) VALUES (?, ?)", (class_name, class_time))
            db.commit()
            return redirect(url_for('view_classes'))
        except Exception as e:
            return f"Error adding class: {str(e)}"

    return render_template('add_class.html')

# View Classes
@app.route('/view_classes')
def view_classes():
    if 'user' not in session:
        return redirect(url_for('login'))

    # Fetch all classes
    classes = query_db("SELECT * FROM classes")
    return render_template('view_classes.html', classes=classes)

# View Members
@app.route('/view_members')
def view_members():
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))
    
    members = query_db("SELECT * FROM members")
    return render_template('view_members.html', members=members)

# Register a Class for a Member
@app.route('/register_class/<int:member_id>', methods=['GET', 'POST'])
def register_class(member_id):
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))

    classes = query_db("SELECT * FROM classes")
    if request.method == 'POST':
        class_id = request.form['class_id']
        
        # Validate class_id input
        if not class_id.isdigit():
            return "Invalid class selection."

        # Register the class for the member
        try:
            db = get_db()
            db.execute("INSERT INTO member_classes (member_id, class_id) VALUES (?, ?)", (member_id, class_id))
            db.commit()
            return redirect(url_for('member_classes', member_id=member_id))
        except Exception as e:
            return f"Error registering class: {str(e)}"
    
    return render_template('register_class.html', member_id=member_id, classes=classes)

@app.route('/member/<int:member_id>/classes')
def member_classes(member_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    # Get member classes
    member = query_db("SELECT * FROM members WHERE id = ?", [member_id], one=True)
    classes = query_db("SELECT c.class_name, c.class_time FROM classes c "
                        "JOIN member_classes mc ON c.id = mc.class_id "
                        "WHERE mc.member_id = ?", [member_id])
    
    return render_template('member_classes.html', member=member, classes=classes)

@app.route('/add_member', methods=['GET', 'POST'])
def add_member():
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))  # Redirect to login if not staff

    if request.method == 'POST':
        name = request.form['name']
        status = request.form['status']
        db = get_db()
        db.execute("INSERT INTO members (name, membership_status) VALUES (?, ?)", (name, status))
        db.commit()
        return redirect(url_for('view_members'))  # Redirect to view members after registration

    return render_template('add_member.html')
@app.route('/delete_member/<int:member_id>', methods=['POST'])
def delete_member(member_id):
    # Ensure the user is logged in and has 'staff' role
    if 'user' not in session or session['role'] != 'staff':
        return redirect(url_for('login'))  # Redirect to login if not staff
    
    # Connect to the database
    db = get_db()

    # Delete the member from the 'members' table
    db.execute("DELETE FROM members WHERE id = ?", [member_id])

    # Delete associated classes from the 'member_classes' table
    db.execute("DELETE FROM member_classes WHERE member_id = ?", [member_id])

    # Commit the changes to the database
    db.commit()

    # Redirect to the 'view_members' page after deletion
    return redirect(url_for('view_members'))

# Logout Route
@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
